const express = require('express');
const bodyParser = require('body-parser');
const morgan = require('morgan');

const path = require('path');

const connectDB = require('./server/database/connection');

//express app
const app = express();


const port = 7000;

//log request
app.use(morgan('tiny'));

// mongodb connection
connectDB();

app.use(express.json()); // for parsing application/json
// parse request to body-parser
app.use(bodyParser.urlencoded({ extended: false }));

//register view engine
app.set('view engine', 'ejs');

//load asset
app.use('/css',express.static(path.resolve(__dirname,"assets/css")))

//middleware and static files
app.use(express.static('public'))
app.use(express.json());
app.use(express.urlencoded());


//express layouts
var expressLayouts = require('express-ejs-layouts');
app.use(expressLayouts);
app.set('layout', 'layouts/layout');

//teacher and student routes
const teachRoutes = require("./routes/teacherRoutes")
const studRoutes = require("./routes/studentRoutes")
app.use("/teacher",teachRoutes);
app.use("/student",studRoutes);

//routes
app.get("/", (req, res) => {
  res.render("index");
});

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});