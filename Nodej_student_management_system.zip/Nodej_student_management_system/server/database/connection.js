const mongoose = require('mongoose');

function connectDB() {
  const connectionString = 'mongodb+srv://prathmesh:admin123@cluster0.qwyifdq.mongodb.net/?retryWrites=true&w=majority';
  mongoose.connect(connectionString, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });

  const db = mongoose.connection;

  db.on('error', console.error.bind(console, 'MongoDB connection error:'));
  db.once('open', () => {
    console.log('Connected to MongoDB');
  });

  return db;
}

module.exports = connectDB;